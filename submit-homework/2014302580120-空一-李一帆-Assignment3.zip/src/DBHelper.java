import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBHelper {
	public Connection con;

	/*
	 * �������ݿ�
	 */
	public DBHelper(String DBurl) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection(DBurl, "root", "123456");
	}
	
	
	public void close() throws SQLException {
		this.con.close();
	}

}
