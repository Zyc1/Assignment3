import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
 * ��ȡ��ҳ�õ���ʦ����ҳurl
 */
public class UrlList2014302580120 {
    List<String> UrlList = new ArrayList<String>();
	public List<String> GetUrlList() throws IOException {
		String url = "http://cs.whu.edu.cn/plus/list.php?tid=36";
		Document doc = Jsoup.connect(url).get();
		
		Elements links = doc.select("a[href]");
		/*
		 * ����ƥ��õ�url
		 */
		Pattern pattern = Pattern.compile("view.php\\?aid=162\\d{1}");
		for (Element link : links) {
		    String urls = link.attr("abs:href") + link.attr("rel");
		    Matcher matcher = pattern.matcher(urls);
		    while(matcher.find()) {
		    	UrlList.add(urls);
		    }
		}
		return UrlList;
	}

}
