import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class HomePageMultiThreading2014302580120 implements Runnable {
	
	private String url;
	public void getUrl(String url) {
		this.url = url;
	}
		
	public void run() {
		Document doc;
		try {
			doc = Jsoup.connect(url).get();
			String str = doc.body().getAllElements().get(0).html().replaceAll("&nbsp;", ""); //��ȥҳ��������&nbsp;���ո��
			doc = Jsoup.parse(str);
			
			/*
			 * ��ȡ������Ϣ
			 */
			Elements ele = doc.select(".about_info").select(".fn_left");
		    Elements li = ele.select("li");
		    String name = li.get(0).text().substring(3);
		    String sex = li.get(2).text().substring(3);
		    String title = li.get(3).text().substring(3);
		    String tel = li.get(5).text().substring(3);
		    String email = li.get(7).text().substring(7);
		    Elements ele2 = doc.getElementsByClass("info_list_ct");
		    String intro = ele2.text();
		    
		    /*
		     * ���Ӳ�д�����ݿ�
		     */
		    DBHelper db = new DBHelper("jdbc:mysql://127.0.0.1/teacher_infor");
		    PreparedStatement sta = db.con.prepareStatement("insert into teacher_infor(name, sex, title, tel, email, intro) values(?, ?, ?, ?, ?, ?)");
		    sta.setString(1, name);
		    sta.setString(2, sex);
		    sta.setString(3, title);
		    sta.setString(4, tel);
		    sta.setString(5, email);
		    sta.setString(6, intro);
		    sta.executeUpdate();
		    
		    sta.close();
		    db.close();
		} catch (IOException | ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}
	
}
