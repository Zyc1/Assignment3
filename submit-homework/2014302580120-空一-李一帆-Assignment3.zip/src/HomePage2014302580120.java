import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class HomePage2014302580120 {
	
	public void HomePage() throws IOException, SQLException, ClassNotFoundException {
		long startMili=System.currentTimeMillis();
		
		/*
		 * �õ���ҳurl
		 */
		UrlList2014302580120 UrlList = new UrlList2014302580120();
		List<String> urlList = UrlList.GetUrlList();
		
		/*
		 * �������ݿ�
		 */
		DBHelper db = new DBHelper("jdbc:mysql://localhost:3306/teacher_infor");
		PreparedStatement sta = db.con.prepareStatement("insert into teacher_infor(name, sex, title, tel, email, intro) values(?, ?, ?, ?, ?, ?)");
		
		/*
		 * ѭ����ȡ������ʦ��ҳ
		 */
		for (String url : urlList) {
			Document doc = Jsoup.connect(url).get();
			String str = doc.body().getAllElements().get(0).html().replaceAll("&nbsp;", ""); //��ȥҳ��������&nbsp;���ո��
			doc = Jsoup.parse(str);
			
			/*
			 * ��ȡ������Ϣ
			 */
			Elements ele = doc.select(".about_info").select(".fn_left"); // ͨ����ʽclassѡ��class�����м��пո�Ĵ���������class="about_info fn_left"��
		    Elements li = ele.select("li");
		    String name = li.get(0).text().substring(3);
		    String sex = li.get(2).text().substring(3);
		    String title = li.get(3).text().substring(3);
		    String tel = li.get(5).text().substring(3);
		    String email = li.get(7).text().substring(7);
		    Elements ele2 = doc.getElementsByClass("info_list_ct");
		    String intro = ele2.text();
		    
		    /*
		     * �������ݿ�
		     */
		    sta.setString(1, name);
		    sta.setString(2, sex);
		    sta.setString(3, title);
		    sta.setString(4, tel);
		    sta.setString(5, email);
		    sta.setString(6, intro);
		    sta.executeUpdate();
		    
		}
		
		/*
		 * �ر����ݿ�
		 */
		sta.close();
		db.close();
		
		long endMili=System.currentTimeMillis();
	    System.out.println("���̺߳�ʱΪ��"+(endMili-startMili)+"����");
	}
	
	public void HomePageMultiThreading() throws IOException {
		long startMili=System.currentTimeMillis();
		UrlList2014302580120 UrlList = new UrlList2014302580120();
		List<String> urlList= UrlList.GetUrlList();
		
		/*
		 * ��ȡ���߳���ȡ
		 */
		for (String url : urlList) {
			HomePageMultiThreading2014302580120 hpmt = new HomePageMultiThreading2014302580120();
			hpmt.getUrl(url);
			Thread thread = new Thread(hpmt);
			thread.start();
		}
		
		long endMili=System.currentTimeMillis();
		System.out.println("���̺߳�ʱΪ��"+(endMili-startMili)+"����");
	}

}
