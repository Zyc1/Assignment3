import java.util.regex.*;


public class Crawler {
	//��������ַ�ӳ�ʼҳ��ץ��
	String baseURL = "http://staff.whu.edu.cn/";
	Pattern pattern = Pattern.compile("href=\"(.*)\"",Pattern.CASE_INSENSITIVE);
	Matcher matcher = pattern.matcher(webpage_content);
	while(matcher.find()){
	    String foundURL = matcher.group(1);
	    if (foundURL.startsWith("http")){
	        System.out.println(foundURL);
	    }else{
	        System.out.println(baseURL + foundURL));
	    }
	}
}
