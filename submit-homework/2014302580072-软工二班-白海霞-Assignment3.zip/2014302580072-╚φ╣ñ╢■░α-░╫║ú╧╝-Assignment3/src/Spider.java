import java.io.*;
import java.util.*;

import javax.swing.text.html.parser.Parser;

import org.jsoup.*;

import com.mysql.jdbc.Buffer;

public class Spider {
	//�������ݿ�
	 public static Connection getConnection() throws Exception {
		return null;
		 
	 }    
	public void singleThreadCrawling() {
		// TODO �Զ����ɵķ������
		Crawler.crawlAll();
		File dir = new File("pages");
		File[] pages = new File[100];
		if (dir.isDirectory()) {
			pages = dir.listFiles();
		} else {
			System.err.println("directory error!");
		}
		for (File page : pages) {
			try {
				Parse.getAll(page);
			} catch (IOException e) {
				System.err.println("parsing error!");
			}
		}
	}

	/*
	 * ���߳�
	 * �ֳ������߳�
	 * ץȡ������
	 */
	public void multithreadingCrawlingUsingThreads() {
		// TODO �Զ����ɵķ������
			Buffer buffer = new Buffer(waitList);
			Thread t1 = new Thread(new Crawler(buffer));
			Thread t2 = new Thread(new Parse(buffer));
			t1.start();
			t2.start();
			t1.join();
			t2.join();
	}

}
