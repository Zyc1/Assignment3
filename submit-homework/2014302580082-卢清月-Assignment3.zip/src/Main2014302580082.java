import java.io.File;
import java.io.IOException;
import java.nio.Buffer;

import com.sun.javafx.scene.paint.GradientUtils.Parser;

public class Main2014302580082 {


	private static Main2014302580082 spider;

	public static void main(String[] args)throws  InterruptedException, IOException  {
		Main2014302580082. spider = new Main2014302580082();
		spider.getLinks();
		spider.singleThread();
		spider.multiThread();

}
	
	private void getLinks() {
		// TODO Auto-generated method stub
		
	}

	//���߳�ץȡ
	public static void singleThread() throws InterruptedException, IOException {
		long startTime1 = System.currentTimeMillis();
		File dir = new File("pages");
		File[] pages = new File[100];
		if (dir.isDirectory()) {
			pages = dir.listFiles();
			long time1 = 0;
			//���̺߳�ʱ
			System.out.println("���߳���ȡ��ʱ��"+(time1-startTime1)+"ms");
		} else {
			System.err.println("����!");
		}
		
		}
		
		//���߳�ץȡ
		//��Ϊ��ȡ�Ͷ�ȡ�����߳�
		public static void multiThread() throws InterruptedException {
			long startTime2 = System.currentTimeMillis();
			long time2=0;
			Buffer buffer = null;
			Thread t1 = new Thread(new Crawler2014302580082(buffer));
			Thread t2 = new Thread();
			t1.start();
			t2.start();
			//���̺߳�ʱ
			System.out.println("���߳���ȡ��ʱ��"+(time2-startTime2)+"ms");
		}
		

	}