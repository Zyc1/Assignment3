import java.io.File;
import java.io.IOException;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.Map;
import java.util.regex.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;


public  class Crawler2014302580082 implements Runnable{
	private Buffer buffer;
	public static boolean endSig = false;
	public  Crawler2014302580082(Buffer b){
		this.buffer = b;	
	}
	//��ȡHTML

	
	public static Document readHTML(File htmlcode) throws IOException {
		Document doc = Jsoup.parse(htmlcode, "GBK");
		return doc;
	}
	public static Document readHTML(String fileName) throws IOException {
		Document doc = Jsoup.parse(new File(fileName), "GBK");
		return doc;
	}
	
	//��ȡһ����ҳ�е����г�����
	public static ArrayList<String> findHref() throws IOException,
	InterruptedException {
    Document doc = readHTML("staff.whu.edu.cn.html");
    Elements links = doc.getElementsByTag("a");
    ArrayList<String> linkList = new ArrayList<String>();
    for (Element link : links) {
	linkList.add(link.attr("href"));
    }
    return linkList;
}
	
	//��ȡ��Ϣ���������ݿ�
	
	public static void getInfo(String[] args) throws IOException{
		Document doc = readHTML("staff.whu.edu.cn.html");
		
		//��URLֱ�Ӽ���HTML�ĵ�
		 Document doc1 = Jsoup.connect("http://staff.whu.edu.cn/").get(); 
		 String title = doc.title();
		 String information = doc.text();
		
		 
		 //��ȡ��ʦ����
		 Elements name = doc.select("h3");
		 
		 //��ȡ�о����򼰽�������
		 Elements a = doc.select("p");
		 String i1=a.select("p").get(0).text();
		 String i2=a.select("p").get(3).text();
		 String i3=a.select("p").get(4).text();
		 
		//���������ʽ��ȡ��ϵ�绰
		 String tel=a.select("p").get(0).text();
		 Pattern t=Pattern.compile("[0-9]{3}-[0-9]{8}");
		 Matcher tel1=t.matcher(tel);
		
		 //���������ʽ��ȡemail
		 String email =a.select("p").get(0).text();
		 Pattern e=Pattern.compile("\\w+@(\\w+\\.)+cn*");
		 Matcher e1=e.matcher(email);
		 	 
	
	}

	

	public void run() {
		
	}
}